import os
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import date

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SECRET_KEY'] = 'key'

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(50), nullable=False)

    def __init__(self, name, email, password):
        self.name = name
        self.email = email
        self.password = password


class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(500))

    def __init__(self, name, description=''):
        self.name = name
        self.description = description


class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref='applications')
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    product = db.relationship('Product', backref='applications')
    application_date = db.Column(db.Date, nullable=False)
    application_status = db.Column(db.String(50), nullable=False)

    def __init__(self, user_id, product_id, application_date, application_status):
        self.user_id = user_id
        self.product_id = product_id
        self.application_date = application_date
        self.application_status = application_status


@app.route("/", methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password1']
        
        user = User.query.filter_by(email=email).first()
        
        if email == "admin@12" and password == "admin":
            session['user_email'] = email
            flash('Вход успешен как администратор!', 'success')
            return redirect(url_for("admin"))

        if user and user.password == password:
            session['user_email'] = user.email
            flash('Вход успешен!', 'success')
            return redirect(url_for("pols"))
        
        flash('Неверный email или пароль!', 'danger')

    return render_template("login.html")


@app.route("/register", methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password1 = request.form['password1']
        password2 = request.form['password2']

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Пользователь с таким email уже существует!', 'danger')
            return redirect(url_for('register'))

        if password1 != password2:
            flash('Пароли не совпадают!', 'danger')
            return redirect(url_for('register'))

        new_user = User(name=name, email=email, password=password1)
        db.session.add(new_user)
        db.session.commit()
        
        flash('Регистрация успешна!', 'success')
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/logout")
def logout():
    session.pop('user_email', None)
    flash('Вы вышли из системы.', 'success')
    return redirect(url_for('login'))


@app.route('/pols', methods=['POST', 'GET'])
def pols():
    if 'user_email' not in session:
        flash('Пожалуйста, войдите в систему.', 'danger')
        return redirect(url_for('login'))

    if 'request' in request.form:  # Изменено: проверяем наличие кнопки request_inventory
        item_name = request.form.get('product_name')
        if not item_name:
            flash('Введите название товара!', 'danger')
            return redirect(url_for('pols'))
        
        product = Product.query.filter_by(name=item_name).first()
        if not product:
            flash('Товар не найден!', 'danger')
            return redirect(url_for('pols'))
        
        user = User.query.filter_by(email=session['user_email']).first()
        if not user:
            flash('Пользователь не найден!', 'danger')
            return redirect(url_for('pols'))
        
        new_request = Application(user_id=user.id, product_id=product.id, application_date=date.today(), application_status='pending')
        db.session.add(new_request)
        db.session.commit()
        flash('Заявка успешно отправлена!', 'success')
    
    return render_template('pols.html') 



@app.route('/admin', methods=['POST', 'GET'])
def admin():
    if 'user_email' not in session or session['user_email'] != "admin@12":
        flash('У вас нет доступа к этой странице.', 'danger')
        return redirect(url_for('login'))

    applications = Application.query.all()

    if request.method == 'POST':
        if 'approve_request' in request.form:
            request_id = int(request.form.get('request_id'))
            selected_request = Application.query.get(request_id)
            selected_request.application_status = 'approved'
            db.session.commit()

        if 'reject_request' in request.form:
            request_id = int(request.form.get('request_id'))
            selected_request = Application.query.get(request_id)
            selected_request.application_status = 'rejected'
            db.session.commit()

    return render_template("admin.html", applications=applications)


@app.route('/api/applications')
def get_applications():
    applications = Application.query.all()
    
    application_list = []
    
    for app in applications:
        application_data = {
            "id": app.id,
            "user": {"name": app.user.name},
            "product": {"name": app.product.name},
            "application_date": app.application_date.strftime("%Y-%m-%d"),
            "application_status": app.application_status
        }
        
        application_list.append(application_data)

    return jsonify(application_list)


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    
    app.run(debug=True)
